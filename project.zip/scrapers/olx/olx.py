import requests as req

OLX_URL = 'https://www.olx.pl/praca/'

def get_data() -> str:
    data = req.get(OLX_URL).text